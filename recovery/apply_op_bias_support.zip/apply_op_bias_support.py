#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path
import re
import shutil

ROOT = Path.cwd()
FILES = {
    "sim": ROOT / "spec2testbench/infrastructure/simulator/pyspice_simulator.py",
    "probe": ROOT / "spec2testbench/infrastructure/simulator/op_bias_probe.py",
    "extractor": ROOT / "spec2testbench/infrastructure/spec_checker/metric_extractor.py",
    "registry": ROOT / "spec2testbench/application/services/llm_metric_registry.py",
    "generator": ROOT / "spec2testbench/infrastructure/testbench/testbench_generator.py",
    "coverage": ROOT / "spec2testbench/domain/entities/metric_coverage.py",
    "harness": ROOT / "spec2testbench/application/services/canonical_harness.py",
    "supported": ROOT / "spec2testbench/domain/registry/supported_tests.py",
    "acp": ROOT / "spec2testbench/application/services/acp_benchmark_runner.py",
}
for key, path in FILES.items():
    if key != "probe" and not path.is_file():
        raise SystemExit(f"ERROR: expected file not found: {path}")


def backup(path: Path) -> None:
    bak = path.with_suffix(path.suffix + ".opbias.bak")
    if not bak.exists():
        shutil.copy2(path, bak)


def write_changed(path: Path, text: str) -> None:
    old = path.read_text(encoding="utf-8")
    if old == text:
        return
    backup(path)
    path.write_text(text, encoding="utf-8")
    print(f"PATCHED: {path.relative_to(ROOT)}")


def add_item_to_named_set(text: str, name: str, item: str) -> tuple[str, bool]:
    m = re.search(rf"(?m)^{re.escape(name)}\s*=\s*\{{", text)
    if not m:
        return text, False
    start = m.end()
    end = text.find("}", start)
    if end < 0:
        return text, False
    block = text[start:end]
    if f'"{item}"' in block or f"'{item}'" in block:
        return text, True
    return text[:end] + f'\n    "{item}",' + text[end:], True


probe_code = '''from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import json
import subprocess

import numpy as np


@dataclass(frozen=True)
class OpBiasProbeResult:
    value: float | None
    devices: tuple[str, ...]
    currents_a: tuple[float, ...]
    status: str
    reason: str | None
    metadata_path: str | None


def needs_op_bias_probe(testbench: Any) -> bool:
    metadata = getattr(testbench, "metadata", None) or {}
    required = {str(x).lower() for x in metadata.get("required_metrics", [])}
    if "minimum_device_drain_current_a" in required:
        return True
    return any(
        getattr(measurement, "name", "").lower() == "minimum_device_drain_current_a"
        for measurement in getattr(testbench, "measurements", [])
    )


def _strip_control_sections_and_end(deck_text: str) -> str:
    kept: list[str] = []
    in_control = False
    for raw_line in deck_text.splitlines():
        token = raw_line.strip().lower()
        if token == ".control":
            in_control = True
            continue
        if in_control:
            if token == ".endc":
                in_control = False
            continue
        if token == ".end":
            continue
        kept.append(raw_line)
    return "\\n".join(kept).rstrip() + "\\n"


def extract_mos_device_names_from_runnable(deck_text: str) -> list[str]:
    names: list[str] = []
    for raw_line in deck_text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith(("*", ".", "+")):
            continue
        token = line.split()[0].lower()
        if token.startswith("m") and token not in names:
            names.append(token)
    return names


def run_op_bias_probe(*, ngspice_path: str, executed_deck_path: Path,
                      artifact_dir: Path, timeout_seconds: float) -> OpBiasProbeResult:
    probe_dir = Path(artifact_dir) / "op_bias_probe"
    probe_dir.mkdir(parents=True, exist_ok=True)
    metadata_path = probe_dir / "op_bias_metadata.json"

    def finish(*, value=None, devices=(), currents=(), status: str,
               reason=None, extra=None) -> OpBiasProbeResult:
        payload = {
            "metric": "minimum_device_drain_current_a",
            "status": status,
            "reason": reason,
            "value": value,
            "devices": list(devices),
            "currents_a": list(currents),
            "executed_deck": str(executed_deck_path),
        }
        if extra:
            payload.update(extra)
        metadata_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        return OpBiasProbeResult(value=value, devices=tuple(devices), currents_a=tuple(currents),
                                 status=status, reason=reason, metadata_path=str(metadata_path))

    try:
        source_text = Path(executed_deck_path).read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return finish(status="NOT_EVALUATED", reason=f"DECK_READ_FAILED:{exc}")

    base = _strip_control_sections_and_end(source_text)
    expanded_path = probe_dir / "expanded_runnable.ckt"
    discovery_path = probe_dir / "discover_mos.ckt"
    discovery_path.write_text(
        base + "\\n.control\\n" + f"listing runnable > {expanded_path.resolve()}\\n" +
        "quit\\n.endc\\n.END\\n", encoding="utf-8")

    try:
        discovery = subprocess.run([str(ngspice_path), "-b", str(discovery_path)],
            cwd=str(Path(executed_deck_path).parent), capture_output=True, text=True,
            timeout=timeout_seconds, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return finish(status="NOT_EVALUATED", reason=f"LISTING_RUN_FAILED:{exc}")
    (probe_dir / "discover_stdout.txt").write_text(discovery.stdout or "", encoding="utf-8")
    (probe_dir / "discover_stderr.txt").write_text(discovery.stderr or "", encoding="utf-8")
    if discovery.returncode != 0 or not expanded_path.is_file():
        return finish(status="NOT_EVALUATED", reason="LISTING_RUNNABLE_FAILED",
                      extra={"discovery_returncode": discovery.returncode})

    expanded_text = expanded_path.read_text(encoding="utf-8", errors="replace")
    devices = extract_mos_device_names_from_runnable(expanded_text)
    if not devices:
        return finish(status="NOT_EVALUATED", reason="NO_MOS_DEVICES_FOUND")

    vectors = [f"@{name}[id]" for name in devices]
    op_values_path = probe_dir / "op_bias.dat"
    op_deck_path = probe_dir / "op_bias.ckt"
    expanded_base = _strip_control_sections_and_end(expanded_text)
    op_deck_path.write_text(
        expanded_base + "\\n.control\\nset filetype=ascii\\nset wr_singlescale\\n" +
        "save " + " ".join(vectors) + "\\n" +
        "op\\n" + f"wrdata {op_values_path.resolve()} " + " ".join(vectors) +
        "\\nquit\\n.endc\\n.END\\n", encoding="utf-8")

    try:
        op_run = subprocess.run([str(ngspice_path), "-b", str(op_deck_path)],
            cwd=str(probe_dir), capture_output=True, text=True,
            timeout=timeout_seconds, check=False)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return finish(status="NOT_EVALUATED", reason=f"OP_RUN_FAILED:{exc}", devices=devices)
    (probe_dir / "op_stdout.txt").write_text(op_run.stdout or "", encoding="utf-8")
    (probe_dir / "op_stderr.txt").write_text(op_run.stderr or "", encoding="utf-8")

    err = (op_run.stderr or "").lower()
    if (op_run.returncode != 0 or "no such device" in err or "no such vector" in err or
            "no convergence" in err or "fatal" in err or not op_values_path.is_file()):
        return finish(status="NOT_EVALUATED", reason="OP_DEVICE_CURRENT_EXTRACTION_FAILED",
                      devices=devices, extra={"op_returncode": op_run.returncode})

    try:
        data = np.loadtxt(op_values_path, dtype=float)
    except (OSError, ValueError) as exc:
        return finish(status="NOT_EVALUATED", reason=f"OP_WRDATA_PARSE_FAILED:{exc}", devices=devices)
    data = np.asarray(data, dtype=float)
    if data.ndim == 0:
        data = data.reshape(1, 1)
    elif data.ndim == 1:
        data = data.reshape(1, -1)
    row = data[-1]
    if row.size == len(devices) + 1:
        raw_currents = row[1:]
    elif row.size >= len(devices):
        raw_currents = row[-len(devices):]
    else:
        return finish(status="NOT_EVALUATED",
                      reason=f"OP_WRDATA_COLUMN_MISMATCH:{row.size}:{len(devices)}", devices=devices)
    if raw_currents.size != len(devices) or not np.all(np.isfinite(raw_currents)):
        return finish(status="NOT_EVALUATED", reason="NONFINITE_OR_INCOMPLETE_DEVICE_CURRENTS",
                      devices=devices)

    currents = [float(x) for x in raw_currents]
    value = float(np.min(np.abs(raw_currents)))
    return finish(status="SUCCESS", value=value, devices=devices, currents=currents,
                  extra={"aggregation": "min(abs(Id))", "device_parameter": "id",
                         "op_values_file": str(op_values_path),
                         "expanded_runnable": str(expanded_path)})
'''
FILES["probe"].write_text(probe_code, encoding="utf-8")
print("CREATED: spec2testbench/infrastructure/simulator/op_bias_probe.py")

# pyspice_simulator hook
p = FILES["sim"]
text = p.read_text(encoding="utf-8")
import_line = ("from spec2testbench.infrastructure.simulator.op_bias_probe import "
               "needs_op_bias_probe, run_op_bias_probe  # S2T_OP_BIAS_V1\n")
if "S2T_OP_BIAS_V1" not in text:
    anchor = "import numpy as np\n"
    if anchor not in text:
        raise SystemExit("ERROR: numpy import anchor not found in pyspice_simulator.py")
    text = text.replace(anchor, anchor + import_line, 1)


def patch_function_probe(src: str, function_name: str, deck_expr: str) -> str:
    start = src.find(f"    def {function_name}(")
    if start < 0:
        raise SystemExit(f"ERROR: function {function_name} not found")
    end = src.find("\n    def ", start + 10)
    if end < 0:
        end = len(src)
    section = src[start:end]
    if "run_op_bias_probe(" in section:
        return src
    anchor = "        if vectors_file.exists():\n            self._wrdata_to_csv(vectors_file, vectors_csv)\n"
    if anchor not in section:
        raise SystemExit(f"ERROR: vectors anchor not found in {function_name}")
    addition = f'''\n        # S2T_OP_BIAS_V1: auxiliary OP proof for MOS drain-current floor.\n        op_bias_probe = None\n        if needs_op_bias_probe(testbench):\n            op_bias_probe = run_op_bias_probe(\n                ngspice_path=self.ngspice_path,\n                executed_deck_path=Path({deck_expr}),\n                artifact_dir=artifact_dir,\n                timeout_seconds=self.timeout,\n            )\n            if op_bias_probe.value is not None:\n                with measures_file.open("a", encoding="utf-8") as handle:\n                    handle.write(\n                        f"\\nminimum_device_drain_current_a = {{op_bias_probe.value:.17g}}\\n"\n                    )\n'''
    section = section.replace(anchor, anchor + addition, 1)
    return src[:start] + section + src[end:]

text = patch_function_probe(text, "_run_native_extraction_passes", "deck_path")
text = patch_function_probe(text, "_collect_native_artifacts_from_run", "executed_deck_path")
write_changed(p, text)

# registry
p = FILES["registry"]
text = p.read_text(encoding="utf-8")
if '"minimum_device_drain_current_a": MetricDefinition(' not in text:
    start = text.find('    "power": MetricDefinition(')
    if start < 0:
        raise SystemExit("ERROR: power MetricDefinition not found")
    close = text.find("\n    ),", start)
    if close < 0:
        raise SystemExit("ERROR: end of power MetricDefinition not found")
    close += len("\n    ),")
    block = '''\n    "minimum_device_drain_current_a": MetricDefinition(\n        metric_name="minimum_device_drain_current_a",\n        semantic_definition=(\n            "Minimum absolute MOSFET drain current across all MOS devices "\n            "at the operating point: min_i(abs(Id_i))."\n        ),\n        compatible_analysis_types=(AnalysisType.OP, AnalysisType.DC),\n        expected_unit="A",\n        required_nodes=(),\n        preferred_backend=MeasurementBackendPreference.NGSPICE_MEASURE,\n        definition_version="minimum_device_drain_current_v1",\n        quantity_type=None,\n        measurement_expression_id="OP_MINIMUM_MOS_DRAIN_CURRENT",\n        required_semantic_guards={"mos_devices_present": True},\n    ),'''
    text = text[:close] + block + text[close:]
write_changed(p, text)

# extractor
p = FILES["extractor"]
text = p.read_text(encoding="utf-8")
needle = '            "idd": self._extract_current,\n'
if '"minimum_device_drain_current_a": self._extract_minimum_device_drain_current,' not in text:
    if needle not in text:
        raise SystemExit("ERROR: idd extractor anchor not found")
    text = text.replace(needle, needle +
        '            "minimum_device_drain_current_a": self._extract_minimum_device_drain_current,\n', 1)
if "def _extract_minimum_device_drain_current(" not in text:
    anchor = "    def _extract_operating_point("
    idx = text.find(anchor)
    if idx < 0:
        raise SystemExit("ERROR: operating point extractor anchor not found")
    method = '''    def _extract_minimum_device_drain_current(self, results: Dict[str, Any]) -> Optional[float]:\n        # Exact-only evidence: never substitute I(Vdd) for a device Id floor.\n        for container in (results.get("native_metrics", {}), results.get("metrics", {}), results):\n            if not isinstance(container, dict):\n                continue\n            value = container.get("minimum_device_drain_current_a")\n            if isinstance(value, (int, float)) and math.isfinite(float(value)):\n                return abs(float(value))\n        return None\n\n'''
    text = text[:idx] + method + text[idx:]
write_changed(p, text)

# generator
p = FILES["generator"]
text = p.read_text(encoding="utf-8")
if 'elif measurement.name == "minimum_device_drain_current_a":' not in text:
    anchor = '''            elif measurement.name in {"quiescent_current", "idd"}:\n                request.setdefault("current_column", 2)\n                request["supply_voltage"] = float(specification.vdd)\n'''
    if anchor not in text:
        raise SystemExit("ERROR: qcurrent request anchor not found")
    addition = '''            elif measurement.name == "minimum_device_drain_current_a":\n                request["device_parameter"] = "id"\n                request["aggregation"] = "minimum_absolute"\n                request["auxiliary_analysis"] = "op"\n'''
    text = text.replace(anchor, anchor + addition, 1)
start = text.find("def _infer_categories_from_metrics")
if start >= 0:
    end = text.find("\n    def ", start + 10)
    if end < 0:
        end = len(text)
    section = text[start:end]
    if '"minimum_device_drain_current_a"' not in section:
        section = section.replace('"current_stability_delta_a",',
                                  '"current_stability_delta_a", "minimum_device_drain_current_a",', 1)
        text = text[:start] + section + text[end:]

# Also extend any explicit per-category DC metric set in this generator.
search_from = 0
while True:
    match = re.search(r'"dc"\s*:\s*\{', text[search_from:])
    if not match:
        break
    block_start = search_from + match.end()
    block_end = text.find("}", block_start)
    if block_end < 0:
        break
    block = text[block_start:block_end]
    if '"minimum_device_drain_current_a"' not in block:
        text = text[:block_end] + ' "minimum_device_drain_current_a",' + text[block_end:]
        block_end += len(' "minimum_device_drain_current_a",')
    search_from = block_end + 1
write_changed(p, text)

# coverage
p = FILES["coverage"]
text = p.read_text(encoding="utf-8")
if '"minimum_device_drain_current_a"' not in text:
    anchor = '    "current_stability_delta_a",\n'
    if anchor not in text:
        raise SystemExit("ERROR: coverage anchor not found")
    text = text.replace(anchor, anchor + '    "minimum_device_drain_current_a",\n', 1)
write_changed(p, text)

# canonical harness
p = FILES["harness"]
text = p.read_text(encoding="utf-8")
updated, found = add_item_to_named_set(text, "DC_METRICS", "minimum_device_drain_current_a")
if found:
    write_changed(p, updated)
else:
    print("WARNING: DC_METRICS set not found in canonical_harness.py")

# supported tests
p = FILES["supported"]
text = p.read_text(encoding="utf-8")
if '"minimum_device_drain_current_a"' not in text:
    anchor = '        "quiescent_current",\n'
    if anchor not in text:
        raise SystemExit("ERROR: supported_tests anchor not found")
    text = text.replace(anchor, anchor + '        "minimum_device_drain_current_a",\n', 1)
write_changed(p, text)

# ACP explicit implementation gate, if present
p = FILES["acp"]
text = p.read_text(encoding="utf-8")
found_gate = False
for set_name in ("IMPLEMENTED_ANALYSES", "SUPPORTED_ANALYSES", "IMPLEMENTED_ANALYSIS_TYPES", "EXECUTABLE_ANALYSES"):
    updated, found = add_item_to_named_set(text, set_name, "op_bias")
    if found:
        found_gate = True
        text = updated
        print(f"ACP gate found: {set_name}")
        break
if found_gate:
    write_changed(p, text)
else:
    print("NOTE: no explicit ACP analysis gate found; generic coverage registry was patched.")

# focused tests
test_path = ROOT / "tests/test_op_bias_probe.py"
test_code = '''from spec2testbench.infrastructure.simulator.op_bias_probe import extract_mos_device_names_from_runnable\nfrom spec2testbench.infrastructure.spec_checker.metric_extractor import MetricExtractor\nfrom spec2testbench.application.services.llm_metric_registry import get_metric_definition\n\n\ndef test_op_bias_extracts_top_and_hierarchical_mos_names():\n    deck = "* flattened\\nm1 out in 0 0 nmos\\nm.xop.m2 outp inp tail tail nmos\\nr1 out 0 1k\\n.end\\n"\n    assert extract_mos_device_names_from_runnable(deck) == ["m1", "m.xop.m2"]\n\n\ndef test_minimum_device_drain_current_is_exact_only():\n    extractor = MetricExtractor()\n    assert extractor.extract({"metrics": {"minimum_device_drain_current_a": 2.5e-6}}, "minimum_device_drain_current_a") == 2.5e-6\n    assert extractor.extract({"currents": {"vdd": 1e-3}}, "minimum_device_drain_current_a") is None\n\n\ndef test_minimum_device_drain_current_has_registry_definition():\n    definition = get_metric_definition("minimum_device_drain_current_a")\n    assert definition is not None\n    assert definition.expected_unit == "A"\n'''
test_path.write_text(test_code, encoding="utf-8")
print("CREATED: tests/test_op_bias_probe.py")
print("DONE. Backups use suffix .opbias.bak")
